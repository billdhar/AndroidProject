package com.example.assignment2;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    private List<ListItem> listItems;
    private Context context;
    private Activity activity;

    private String headerKey = "header";
    private String genreKey = "genre";
    private String imageKey = "image";
    private String descriptionKey = "description";

    public MyAdapter(List<ListItem> listItems, Context context, Activity activity) {
        this.listItems = listItems;
        this.context = context;
        this.activity = activity;
    }

    @NonNull
    @Override
    public MyAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.my_text_view, viewGroup, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyAdapter.MyViewHolder myViewHolder, int positiom) {
        final ListItem listItem = listItems.get(positiom);

        myViewHolder.textViewHead.setText(listItem.getHeader());
        myViewHolder.textViewDesc.setText(listItem.getGenre());

        myViewHolder.layout_list_items.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (MainActivity.orientation == 1) {
                    // Landscape
                    Intent intent = new Intent();
                    intent.putExtra(headerKey, listItem.getHeader());
                    intent.putExtra(genreKey, listItem.getGenre());
                    intent.putExtra(imageKey, listItem.getImageResource());
                    intent.putExtra(descriptionKey, listItem.getDescription());
                    activity.setResult(3, intent);
                    activity.finish();
                }
                else {
                    MainActivity.itemName.setText(listItem.getHeader());
                    MainActivity.itemImage.setImageResource(listItem.getImageResource());
                    MainActivity.itemDescription.setText(listItem.getDescription());
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return listItems.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        public TextView textViewHead;
        public TextView textViewDesc;

        public LinearLayout layout_list_items;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            textViewHead = (TextView) itemView.findViewById(R.id.textView_heading);
            textViewDesc = (TextView) itemView.findViewById(R.id.textView_description);
            layout_list_items = (LinearLayout) itemView.findViewById(R.id.layout_movie_list_items);
        }
    }
}
