package com.example.assignment2;

public class ListItem {
    private String header;
    private String genre;
    private int imageResource;
    private String description;

    public ListItem(String header, String genre) {
        this.header = header;
        this.genre = genre;
    }

    public ListItem(String header, String genre, String description) {
        this.header = header;
        this.genre = genre;
        this.description = description;
    }

    public ListItem(String header, String genre, int imageResource, String description) {
        this.header = header;
        this.genre = genre;
        this.description = description;
        this.imageResource = imageResource;
    }

    public String getHeader() {
        return header;
    }

    public String getGenre() {
        return genre;
    }

    public int getImageResource() {
        return imageResource;
    }

    public String getDescription() {
        return description;
    }
}
