package com.example.assignment2;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ItemListFragment extends Fragment {


    private TextView descriptionLandscape;

    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    private List<ListItem> myDataset;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.item_list_fragment, parent, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {

        recyclerView = (RecyclerView)view.findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(view.getContext());
        recyclerView.setLayoutManager(layoutManager);

        addData();

        mAdapter = new MyAdapter(myDataset, view.getContext(), getActivity());
        recyclerView.setAdapter(mAdapter);
    }

    private void addData() {
        myDataset = new ArrayList<>();
        myDataset.add(new ListItem("Avengers: Endgame", "Action", R.drawable.avengers_endgame,"Adrift in space with no food or water, Tony Stark sends a message to Pepper Potts as his oxygen supply starts to dwindle. Meanwhile, the remaining Avengers -- Thor, Black Widow, Captain America and Bruce Banner -- must figure out a way to bring back their vanquished allies for an epic showdown with Thanos -- the evil demigod who decimated the planet and the universe."));
        myDataset.add(new ListItem("Spider-Man: Far From Home", "Comedy", R.drawable.spiderman_far_from_home, "Following the events of Avengers: Endgame, Spider-Man must step up to take on new threats in a world that has changed forever."));
        myDataset.add(new ListItem("Captain Marvel", "Action", R.drawable.captain_marvel, "Captain Marvel is an extraterrestrial Kree warrior who finds herself caught in the middle of an intergalactic battle between her people and the Skrulls. Living on Earth in 1995, she keeps having recurring memories of another life as U.S. Air Force pilot Carol Danvers. With help from Nick Fury, Captain Marvel tries to uncover the secrets of her past while harnessing her special superpowers to end the war with the evil Skrulls."));
        myDataset.add(new ListItem("Aladdin", "Comedy", R.drawable.aladdin, "Aladdin is a lovable street urchin who meets Princess Jasmine, the beautiful daughter of the sultan of Agrabah. While visiting her exotic palace, aladdin stumbles upon a magic oil lamp that unleashes a powerful, wisecracking, larger-than-life genie. As aladdin and the genie start to become friends, they must soon embark on a dangerous mission to stop the evil sorcerer Jafar from overthrowing young Jasmine's kingdom."));
        myDataset.add(new ListItem("Brightburn", "Horror", R.drawable.brightburn, "What if a child from another world crash-landed on Earth, but instead of becoming a hero to mankind, he proved to be something far more sinister? With brightburn, the visionary filmmaker of Guardians of the Galaxy and Slither presents a startling, subversive take on a radical new genre: superhero horror."));
        myDataset.add(new ListItem("Alita: Battle Angel", "Action", R.drawable.alita, "Set several centuries in the future, the abandoned alita is found in the scrapyard of Iron City by Ido, a compassionate cyber-doctor who takes the unconscious cyborg alita to his clinic. When alita awakens, she has no memory of who she is, nor does she have any recognition of the world she finds herself in. As alita learns to navigate her new life and the treacherous streets of Iron City, Ido tries to shield her from her mysterious past."));
        myDataset.add(new ListItem("How to Train Your Dragon: The Hidden World", "Comedy", R.drawable.how_to_train_your_dragon, "DescriptionFrom DreamWorks Animation comes a surprising tale about growing up, finding the courage to face the unknown…and how nothing can ever train you to let go. What began as an unlikely friendship between an adolescent Viking and a fearsome Night Fury dragon has become an epic adventure spanning their lives. Welcome to the most astonishing chapter of one of the most beloved animated franchises in film history: How to Train Your Dragon: The Hidden World. Now chief and ruler of Berk alongside Astrid, Hiccup has created a gloriously chaotic dragon utopia. When the sudden appearance of female Light Fury coincides with the darkest threat their village has ever faced, Hiccup and Toothless must leave the only home they’ve known and journey to a hidden world thought only to exist in myth. As their true destines are revealed, dragon and rider will fight together—to the very ends of the Earth—to protect everything they’ve grown to treasure. For How to Train Your Dragon: The Hidden World, series director Dean DeBlois returns alongside the all-star cast. The film is produced by Brad Lewis (Ratatouille, ANTZ) and Bonnie Arnold (Toy Story, How to Train Your Dragon,How to Train Your Dragon 2)."));
    }
}
