package com.example.assignment2;

import android.content.Context;
import android.telephony.PhoneStateListener;
import android.widget.Toast;

public class MyPhoneStateListener extends PhoneStateListener {

    private Context context;

    public MyPhoneStateListener(Context context) {
        this.context = context;
    }

    @Override
    public void onCallStateChanged(int state, String phoneNumber) {
        super.onCallStateChanged(state, phoneNumber);

        if (state == 1) {
            String msg = "You're Getting a Call From: " + phoneNumber;
            int duration = Toast.LENGTH_LONG;
            Toast toast = Toast.makeText(context, msg, duration);
            toast.show();
        }
    }
}
