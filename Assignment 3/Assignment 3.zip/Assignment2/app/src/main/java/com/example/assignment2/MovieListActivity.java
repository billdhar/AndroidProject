package com.example.assignment2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MovieListActivity extends AppCompatActivity {

    private String headerKey = "header";
    private String genreKey = "genre";
    private String imageKey = "image";
    private String descriptionKey = "description";

    private Button cancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_list);

        cancel = (Button) findViewById(R.id.button_cancel);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.putExtra(headerKey, "");
                intent.putExtra(genreKey, "");
                intent.putExtra(imageKey, "");
                intent.putExtra(descriptionKey, "No Movie Selected");
                setResult(3, intent);
                finish();
            }
        });
    }
}
