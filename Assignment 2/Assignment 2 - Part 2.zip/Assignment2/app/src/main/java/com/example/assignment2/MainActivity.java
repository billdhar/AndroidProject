package com.example.assignment2;

import android.content.Intent;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentContainer;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public static int orientation = 1;
    static final int REQUEST_IMAGE_CAPTURE = 1;

    public static TextView itemDescription;
    public static TextView itemName;
    public static ImageView itemImage;
    public static ImageView imageView;

    FragmentContainer fragmentContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        orientation = getResources().getConfiguration().orientation;

        if (orientation != 1) {
            setContentView(R.layout.activity_main);
            imageView = (ImageView) findViewById(R.id.imageView);
        }
        else {
            setContentView(R.layout.activity_main);
            imageView = (ImageView) findViewById(R.id.imageView2);
        }

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                    startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
                }
            }
        });

        /*
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        ItemListFragment itemListFragment = new ItemListFragment();
        ItemDescriptionFragment itemDescriptionFragment;
        if (orientation == 1) {
            fragmentTransaction.add(R.id.item_list_fragment, itemListFragment);
        }
        else {
            fragmentTransaction.add(R.id.item_list_fragment, itemListFragment);
            itemDescriptionFragment = new ItemDescriptionFragment();
            fragmentTransaction.add(R.id.item_description_fragment, itemDescriptionFragment);
        }

        fragmentTransaction.commit();
        */
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            imageView.setImageBitmap(imageBitmap);
        }
    }

}
