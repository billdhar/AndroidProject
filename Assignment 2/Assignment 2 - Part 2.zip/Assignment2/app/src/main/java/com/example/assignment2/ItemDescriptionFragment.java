package com.example.assignment2;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class ItemDescriptionFragment extends Fragment {

    private ImageView itemImage;
    private TextView itemName;
    private TextView itemDescription;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.item_description_fragment, parent, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        itemImage = (ImageView) view.findViewById((R.id.imageView_movie_image));
        itemName = (TextView) view.findViewById(R.id.textView_movie_name);
        itemDescription = (TextView) view.findViewById(R.id.textView_movie_description);

        MainActivity.itemName = itemName;
        MainActivity.itemDescription = itemDescription;
        MainActivity.itemImage = itemImage;
    }
}
