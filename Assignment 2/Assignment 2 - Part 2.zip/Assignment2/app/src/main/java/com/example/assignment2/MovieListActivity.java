package com.example.assignment2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MovieListActivity extends AppCompatActivity {

    private String headerKey = "header";
    private String genreKey = "genre";
    private String imageKey = "image";
    private String descriptionKey = "description";

    private ImageView movieImage;
    private TextView movieName;
    private TextView movieDescription;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_list);

        Intent intent = getIntent();
        String header = intent.getStringExtra(headerKey);
        String genre = intent.getStringExtra(genreKey);
        int image = intent.getIntExtra(imageKey, 0);
        String description = intent.getStringExtra(descriptionKey);

        movieImage = (ImageView) findViewById(R.id.imageView_movie_image);
        movieName = (TextView) findViewById(R.id.textView_movie_name);
        movieDescription = (TextView) findViewById(R.id.textView_movie_description);

        movieName.setText(header);
        movieDescription.setText(description);
        movieImage.setImageResource(image);
    }
}
